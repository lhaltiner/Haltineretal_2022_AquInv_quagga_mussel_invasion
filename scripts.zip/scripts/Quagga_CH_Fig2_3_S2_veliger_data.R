# Haltiner L., Zhang H. et al. 2022
# The distribution and spread of quagga mussels in perialpine lakes north of the Alps
# Aquatic Invasions 
# code by Haltiner L, Dennis SR, Zhang H

# Script for Figure 2, 3 and S2


#libraries
library(ggplot2)
library(viridis)
library(scales)
library(tidyverse)
library(lubridate)
library(ggthemes)
library(ggpubr)
library(ggforce)


#ggplot settings
theme_set( theme_classic()+theme_bw(base_size = 16) + 
            theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(), 
                  panel.border = element_blank(), axis.line = element_line()))

#load the data and edit structure
veliger <- read.table("./data/veliger_data.txt", header=T) #is the same as wLG

veliger$date <- dmy(veliger$date)
veliger$jday <- yday(veliger$date)
veliger$yr <- year(veliger$date)
veliger$mon <- month(veliger$date)
veliger$longlake<- factor(veliger$lake, levels=c("Lake_Biel","Lake_Constance","Lake_Geneva","Lake_Murten","Lake_Neuchatel","Lake_Thun","Lake_Zurich","Lake_Zurich_Obersee" ),
                      labels=c("Lake Biel","Lake Constance","Lake Geneva","Lake Murten","Lake Neuchatel","Lake Thun","Lake Zurich", "Lake Zurich"))


#filter the data 
veliger_pel <- veliger %>% #for data older than 2020, only data from pelagic sampling 
  filter(yr < 2020, ind_m3 > 0, type == "pelagic") %>%
  group_by(lake,site, yr) %>% #and calculate the season length (in months), when veligers observed
  mutate(season_length = max(mon) - min(mon))


######Figure 3: veliger appearance over the year####
# code by SR Dennis

plot3<- ggplot(veliger_pel, aes(y = season_length, x = yr)) +
  scale_colour_colorblind() +
  theme_classic() +
  theme(legend.position=c(0.12,0.8)) +
  theme(legend.title = element_blank()) +
  xlim(2000, 2020) +
  labs(x = "Year", y = "No. months when veligers present") +
  geom_point(colour="grey",cex=0.25) +
  geom_smooth(aes(colour = longlake))
plot3


######Statistics: veligers and season length############
# code by SR Dennis

model_veliger <- lmerTest::lmer(season_length ~ scale(yr) * longlake + (1 | site), veliger_pel)
summary(model_veliger)
anova(model_veliger)


######Figure 2: Veligers over time############
#code by H Zhang

##ggplot settings
theme_set(theme_classic()+theme(panel.background=element_blank(),panel.border=element_blank())+
            theme(plot.title=element_text(size=10))+
            theme(axis.text.x=element_text(size=8))+
            theme(axis.text.y=element_text(size=8))+
            theme(axis.title.x=element_blank())+
            theme(axis.title.y=element_text(size=8))+
            theme(axis.line=element_line(size=0.3,linetype="solid",color="black"))+
            theme(axis.ticks=element_line(size=0.3,color="black"))  )



#filter for data  newer than 2010
v <- subset(veliger, date>"2010-01-01")

#edit the data
colnames(v)[colnames(v)=='ind_m3']<-'abundance'
v$abundance<-as.numeric(as.character(v$abundance))


##Lake Constance
#edit the data
vc<-v[v$site=='Fischbach-Uttwil_deepest_site',]###choose FU

#2019 data was collected as depth separated samples. for the plot, we ndeed to combine it
vc2019<-subset(vc,date>"2019-01-01")##choose year 2019
vc2019<-vc2019[!vc2019$depthmax=='200',] #remove the very deep values

#calculate the proportion of every depth interval
vc2019<-vc2019%>% group_by(date)%>%
  mutate(proption=(depthmax-depthmin)/100*abundance)

#collapse the data for 1 value per date according to their proportion per depth interval
vc2019<-vc2019%>% group_by(date)%>%
  dplyr::summarise(abundance=sum(proption))

#filter the data to keep only 0-100m integrated samples
vc<-vc%>%filter(vc$depthmin=='0'& vc$depthmax=='100')
vc<-vc[,c(4,7)]

vc<-rbind(vc,vc2019)

#plot the data
pc <- ggplot(data=vc, aes(x=date, y=abundance)) +
  geom_bar(stat="identity")+ #,width=1
  scale_x_date(limits=c(as.Date("2010-01-01"),as.Date("2020-01-01")),date_breaks="1 year",date_labels="%Y")+
  geom_vline(xintercept=as.numeric(as.Date("2016-05-01")),linetype=4,size=0.4,color="red")+
  ggtitle("Lake Constance")+
  scale_y_continuous(limit=c(0,10000),expand=c(0,0))+
  ylab(c(expression(paste("veliger abundance"~~(ind.~m^{-3})))))
pc

##Lake Geneva
#filter the data for only LG data of OLA source
vg<-v[v$source=='Lacs_Observatory_National_Research_Institute_for_Agriculture_Food_and_Environment',]


#plot the data
pg <- ggplot(data=vg,aes(x=date, y=abundance))+
  geom_bar(stat="identity")+ #,width=1
  scale_x_date(limits=c(as.Date("2010-01-01"),as.Date("2020-01-01")),date_breaks="1 year",date_labels="%Y")+
  geom_vline(xintercept=as.numeric(as.Date("2015-12-01")),linetype=4,size=0.4,color="red")+
  ggtitle("Lake Geneva")+
  scale_y_continuous(limit=c(0,10000),expand=c(0,0))+
  ylab(c(expression(paste("veliger abundance"~~(ind.~m^{-3})))))

pg


##Lake Neuchatel
#filter the data
vn<-v[v$longlake=='Lake Neuchatel',]###choose NEU

#plot the data
pn <- ggplot(data=vn, aes(x=date, y=abundance)) +
  geom_bar(stat="identity",width=14)+
  scale_x_date(limits=c(as.Date("2010-01-01"),as.Date("2020-01-01")),date_breaks="1 year",date_labels="%Y")+
  geom_vline(xintercept=as.numeric(as.Date("2017-12-01")),linetype=4,size=0.4,color="red")+
  ggtitle("Lake Neuchâtel")+
  scale_y_continuous(limit=c(0,5000),expand=c(0,0))+
  ylab(c(expression(paste("veliger abundance"~~(ind.~m^{-3})))))
pn

##Lake Biel
#filter the data
vb<-v[v$lake=='Lake_Biel',]

#plot the data
pb <- ggplot(data=vb, aes(x=date, y=abundance)) +
  geom_bar(stat="identity",width=14)+
  scale_x_date(limits=c(as.Date("2010-01-01"),as.Date("2020-02-01")),date_breaks="1 year",date_labels="%Y")+
  geom_vline(xintercept=as.numeric(as.Date("2019-12-01")),linetype=4,size=0.4,color="red")+
  ggtitle("Lake Biel")+
  scale_y_continuous(limit=c(0,5000),expand=c(0,0))+
  ylab(c(expression(paste("veliger abundance"~~(ind.~m^{-3})))))
pb

##Lake Murten
#filter the data
vm<-v[v$lake=='Lake_Murten',]

#plot the data
pm <- ggplot(data=vm, aes(x=date, y=abundance)) +
  geom_bar(stat="identity",width=14)+
  scale_x_date(limits=c(as.Date("2010-01-01"),as.Date("2020-01-01")),date_breaks="1 year",date_labels="%Y")+
  ggtitle("Lake Murten")+
  scale_y_continuous(limit=c(0,1500),expand=c(0,0))+
  ylab(c(expression(paste("veliger abundance"~~(ind.~m^{-3})))))
pm

##Lake Thun
#filter the data
vt<-v[v$lake=='Lake_Thun',]###choose THU

#plot the data
pt <- ggplot(data=vt, aes(x=date, y=abundance)) +
  geom_bar(stat="identity",width=14)+
  scale_x_date(limits=c(as.Date("2010-01-01"),as.Date("2020-01-01")),date_breaks="1 year",date_labels="%Y")+
  ggtitle("Lake Thun")+scale_y_continuous(limit=c(0,50),expand=c(0,0))+
  ylab(c(expression(paste("veliger abundance"~~(ind.~m^{-3})))))
pt

##Lake Zurich-Obersee Lachen
#filter the data
vz<-v[v$site=='Lachen',]

#plot the data
pz <- ggplot(data=vz, aes(x=date, y=abundance)) +
  geom_bar(stat="identity",width=14)+
  scale_x_date(limits=c(as.Date("2010-01-01"),as.Date("2020-01-01")),date_breaks="1 year",date_labels="%Y")+
  ggtitle("Lake Zurich-Obersee Lachen")+
  scale_y_continuous(limit=c(0,15000),expand=c(0,0))+
  ylab(c(expression(paste("veliger abundance"~~(ind.~m^{-3})))))
pz

##Lake Zurich-Zürichsee Thalwil
#filter the data
vzt<-v[v$site=='Thalwil_deepest_site',]

#plot the data
pzt <- ggplot(data=vzt, aes(x=date, y=abundance)) +
  geom_bar(stat="identity",width=14)+
  scale_x_date(limits=c(as.Date("2010-01-01"),as.Date("2020-01-01")),date_breaks="1 year",date_labels="%Y")+
  ggtitle("Lake Zurich-Zürichsee Thalwil")+
  scale_y_continuous(limit=c(0,15000),expand=c(0,0))+
  ylab(c(expression(paste("veliger abundance"~~(ind.~m^{-3})))))
pzt

###combine the plots
all_veligers<-ggarrange(pc,pg,pn,pb,pm,pt,pz,pzt,ncol=2,nrow=4)
all_veligers




######Figure S2: Veligers in drinking water inlet pipes#######
#code by H Zhang

#ggplot settings
theme_set(theme_classic()+
            theme(panel.background=element_blank(),panel.border=element_blank())+
            theme(axis.line=element_line(size=0.8,linetype="solid"))+
            theme(plot.title=element_text(size=12))+
            theme(axis.text.x=element_text(angle=90,size=10))+
            theme(axis.text.y=element_text(size=10))+
            theme(axis.title.x=element_blank())+
            theme(axis.title.y=element_blank()))

#filter the data: only data from inlet pipes
veliger_inlet <- v[v$type=="inlet",]

##Lake Constance-Sipplingen
vcs<-veliger_inlet[veliger_inlet$site=="Sipplingen",]

pcs <- ggplot(data=vcs, aes(x=date, y=abundance)) +
  facet_zoom(ylim=c(0,300), zoom.size = 1)+
  geom_line(size=0.5)+
  geom_point(cex=1.2)+
  geom_vline(xintercept=as.numeric(as.Date("2016-05-01")),linetype=4,size=0.8,color="red")+
  ggtitle("Lake Constance-Sipplingen")+
  scale_y_continuous(expand = c(0,0))+
  scale_x_date(limits=c(as.Date("2010-03-01"),as.Date("2020-06-01")),date_breaks="1 year",date_labels="%Y")
  
pcs


##Lake Geneva-inlet pipes
#St Suplice
vgs<-veliger_inlet[veliger_inlet$site=="St_Sulpice",]

pgs <- ggplot(data=vgs, aes(x=date, y=abundance)) +
  geom_line(size=0.5)+
  geom_point(cex=1.2)+
  geom_vline(xintercept=as.numeric(as.Date("2015-12-01")),linetype=4,size=0.8,color="red")+
  ggtitle("Lake Geneva-St Suplice")+
  scale_y_continuous(limit=c(0,300),expand = c(0,0))+
  scale_x_date(limits=c(as.Date("2010-03-01"),as.Date("2020-06-01")),date_breaks="1 year",date_labels="%Y")
pgs

#Lutry
vgl<-veliger_inlet[veliger_inlet$site=="Lutry",]

pgl <- ggplot(data=vgl, aes(x=date, y=abundance))+
  geom_line(size=0.5)+
  geom_point(cex=1.2)+
  geom_vline(xintercept=as.numeric(as.Date("2015-12-01")),linetype=4,size=0.8,color="red")+
  ggtitle("Lake Geneva-Lutry")+
  scale_y_continuous(limit=c(0,300),expand = c(0,0))+
  scale_x_date(limits=c(as.Date("2010-03-01"),as.Date("2020-06-01")),date_breaks="1 year",date_labels="%Y")
pgl

##Lake Zurich-inlet pipes
#Moos
vzm<-veliger_inlet[veliger_inlet$site=="Kilchberg_MÃ¶nchhof_Moos",]

pzm<- ggplot(data=vzm, aes(x=date, y=abundance)) +
  geom_line(size=0.5)+
  geom_point(cex=1.2)+
  ggtitle("Lake Zurich-Moos")+
  scale_y_continuous(limit=c(0,300),expand = c(0,0))+
  scale_x_date(limits=c(as.Date("2010-06-01"),as.Date("2020-06-01")),date_breaks="1 year",date_labels="%Y")
pzm

#Lengg
vzl<-veliger_inlet[veliger_inlet$site=="Zurich_Tiefenbrunnen_Lengg",]

pzl<- ggplot(data=vzl, aes(x=date, y=abundance)) +
  geom_line(size=0.5)+
  geom_point(cex=1.2)+
  ggtitle("Lake Zurich-Lengg")+
  scale_y_continuous(limit=c(0,300),expand = c(0,0))+
  scale_x_date(limits=c(as.Date("2010-06-01"),as.Date("2020-06-01")),date_breaks="1 year",date_labels="%Y")
pzl

#arrange  the plots
plot_velgigers_inlet<-ggarrange(ggarrange(pzm,pzl,pgs,pgl,ncol=2,nrow=2),pcs,nrow=2,heights=c(0.66,0.34))
annotate_figure(plot_velgigers_inlet,left=text_grob(c(expression(paste("veliger abundance"~~(individuals/m^{3})))),size=12,rot=90))



