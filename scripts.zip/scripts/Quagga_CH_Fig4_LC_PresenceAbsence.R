# Haltiner L., Zhang H. et al. 2022
# The distribution and spread of quagga mussels in perialpine lakes north of the Alps
# Aquatic Invasions 
# Script by J Tyrell DeWeber


# Script for Figure 4



# Libraries
library(sp)
library(rgdal)
library(raster)


# Read in the Lake Constance outline shape file 
lake <- readOGR(dsn = './data', layer = 'ConstanceShape_UTM')

# Read in tributary lines 
tribs <- readOGR(dsn = './data', layer = 'BodenseeFewSelectedTribs_UTM')

muss.df <- read.table('./data/lakeconstance_quagga_zebra_presence_absence.txt', header = T, sep = '\t')

years <- unique(muss.df$year) # Reference for number of years 

muss <- SpatialPointsDataFrame(coords = muss.df[,c(5,6)], data = muss.df, proj4string = crs(lake))


par(mfrow = c(5,1), mar = c(0.5,0.5,0.5,0.5)) 

for(i in 1:length(years)) { 
  
  plotdata <- muss[muss$year == years[i],]
  
  plot.new()
  plot.window(xlim = bbox(lake)[1,], ylim = bbox(lake)[2,]) # Get bounding box of points so all fit 
  
  plot(lake, add = T, lwd = 1.2, col = 'grey', border = 'grey') 
  plot(tribs, add = T, lwd = 1.5, col = 'grey')
  points(plotdata[plotdata$dbug_binary == 0,], col = 'black', pch = 22, cex = 1.2, bg = 'white')
  points(plotdata[plotdata$dbug_binary ==1,], col = 'black', pch = 19, cex = 1.2)
  
  
  title(main = years[i], line = -5, adj = 0.8, cex.main = 1.5)
  
  if(i == 5) { 
    scalebar(d = 20000, type = 'bar', divs = 2, label = c('0','','20 km'), cex = 1.5)
  }
  
  if(i == 1) { 
    legend(x = 'bottomleft',legend = c('Observed','Unobserved'), pch = c(19,22), col = c('black','black'), bty = 'n', cex = 1.5)
  }
}

#north.arrow(xb = 518000, yb = 5259000, len = 1000, )




pdf('QuaggaMussel_Occurrence_Annual_Color.pdf', height = 10, width = 4) 

par(mfrow = c(5,1), mar = c(0.5,0.5,0.5,0.5)) 

for(i in 1:length(years)) { 
  
  plotdata <- muss[muss$year == years[i],]
  
  plot.new()
  plot.window(xlim = bbox(muss)[1,], ylim = bbox(muss)[2,]) # Get bounding box of points so all fit 
  
  plot(lake, add = T, lwd = 1.2, col = 'deepskyblue', border = 'deepskyblue') 
  plot(tribs, add = T, lwd = 1.5, col = 'deepskyblue')
  points(plotdata[plotdata$bugbin == 0,], col = 'black', pch = 22, cex = 1.2, bg = 'white')
  points(plotdata[plotdata$bugbin ==1,], col = 'black', pch = 19, cex = 1.2)
  
  
  title(main = years[i], line = -5, adj = 0.8, cex.main = 1.5)
  
  if(i == 5) { 
    scalebar(d = 20000, type = 'bar', divs = 2, label = c('0','','20 km'), cex = 1.5)
  }
  
  if(i == 1) { 
    legend(x = 'bottomleft',legend = c('Observed','Unobserved'), pch = c(19,22), col = c('black','black'), bty = 'n', cex = 1.5)
  }
}

dev.off() 


