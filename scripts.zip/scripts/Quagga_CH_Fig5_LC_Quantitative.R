# Haltiner L., Zhang H. et al. 2022
# The distribution and spread of quagga mussels in perialpine lakes north of the Alps
# Aquatic Invasions 
# Script by J Tyrell DeWeber


# Script for Figure 5


library(sp)
library(rgdal)
library(raster)
library(mapplots)


# Read in the Lake Constance outline shape file 
lake <- readOGR(dsn = './data', layer = 'ConstanceShape_UTM')

# Read in tributary lines 
tribs <- readOGR(dsn = './data', layer = 'BodenseeFewSelectedTribs_UTM')

muss.df <- read.table('./data/lakeconstance_quagga_zebra_proportions.txt', header = T, sep = '\t')
head(muss.df)

years <- unique(muss.df$year) # Reference for number of years 

muss.df$Dbug_m2 <- muss.df$dreis_m2_tota*muss.df$proportion_Dbug

muss.df$Dpoly_m2 <- muss.df$dreis_m2_tota*(1-muss.df$proportion_Dbug)

muss.sp <- SpatialPointsDataFrame(coords = muss.df[,c(4,5)], data = muss.df, proj4string = crs(lake))

class(muss.sp)

# Define the class intervals for plotting size using Fisher-Jenks 
#intervs <- classIntervals(muss$Dbug_m2, n = 10, style = 'fisher') 
intervs <- c(0,100,500,1000,5000,15000) 

hist.abund <- hist(muss.sp@data$dreis_m2_tota, breaks = intervs, plot = F)

cex.seq <- c(1.5,3,4,5,7)

cex.leg <- c(2,4,7)

par(mfrow = c(4,1), mar = c(0,0,0,0)) 

for(i in 1:length(years)) { 
  
  plotdata <- muss.sp[muss.sp$year == years[i],]
  
  cut.abund <- as.numeric(cut(plotdata$dreis_m2_tota, breaks = intervs, right = T))
  
  plot.new()
  plot.window(xlim = c(bbox(tribs)[1,1],bbox(lake)[1,2]), ylim = c(bbox(lake)[2,1]-1000,bbox(lake)[2,2])) # Get bounding box of points so all fit 
  
  plot(lake, add = T, col = 'grey', border = 'grey') 
  plot(tribs, add = T, lwd = 1.5, col = 'grey')
  
  #points(plotdata, col = 'black', pch = 16, cex = cex.seq[cut.quag])
  
  plot.noquag <- plotdata[plotdata$Dbug_m2 == 0,] 
  # Add pie charts for zebra and quagga mixed sites 
  for(j in 1:nrow(plot.noquag)) { 
    if(nrow(plot.noquag) > 0) { 
      add.pie(z= c(plot.noquag$Dpoly_m2[j]), x = coordinates(plot.noquag)[j,1], 
              y = coordinates(plot.noquag)[j,2], radius = 400*cex.seq[cut.abund[j]], 
              col = c('aquamarine2'), labels = '', border = c('aquamarine2'))
    }
  }
  
  #points(plotdata[plotdata$Dbug_m2 == 0,], cex = cex.seq[cut.abund], bg = 'aquamarine2', col = 'aquamarine2', pch = 21) 
  
  plot.quag <- plotdata[plotdata$Dbug_m2 > 0,] 
  
  # Add pie charts for zebra and quagga mixed sites 
  for(j in 1:nrow(plot.quag)) { 
    add.pie(z= c(plot.quag$Dpoly_m2[j], plot.quag$Dbug_m2[j]), x = coordinates(plot.quag)[j,1], 
            y = coordinates(plot.quag)[j,2], radius = 400*cex.seq[cut.abund[j]], col = c('aquamarine2','chocolate'), labels = '', border = c('aquamarine2','chocolate'))
    
  }
  
  title(main = years[i], line = -6, adj = 0.8, cex.main = 2)
  
  if(i == 4) { 
    scalebar(d = 20000, type = 'bar', divs = 2, label = c('0','','20 km'), cex = 1.5)
  }
  
  if(i == 1) { 
    legend(x = 'bottomleft',legend = c('Zebra','Quagga'), fill = c('aquamarine2','chocolate'), bty = 'n', border = F, cex = 1.6)
  }
  
  
  if(i == 2) { 
    legend(x = 'bottomleft',legend = c('1-100','101-500','501-1000','1001-5000','>5000'), 
           pch = c(rep(1,length(cex.seq))), col = c('black'), bty = 'n', cex = 1.5, pt.cex = c(cex.seq), 
           y.intersp = 1.8, x.intersp = c(1.5), ncol = 2)
  }	
  
}

