# Haltiner L., Zhang H. et al. 2022
# The distribution and spread of quagga mussels in perialpine lakes north of the Alps
# Aquatic Invasions 


# script for Figure 6 and S3



#libraries
library(ggplot2)
library(viridis)
library(scales)
library(tidyverse)
library(nlme)
library(glmmTMB)
library(DHARMa)
library(multcomp)


#ggplot settings
theme_set(theme_bw(base_size = 16) + 
            theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(), 
                  panel.border = element_blank(), axis.line = element_line()))


##load data source file and edit
#Lake Constance depth monitoring 2019
LC_depth <- read.table("./data/lakeconstance_depth_dreissena_sampling_2019.txt", header=T)

#edit depth as a factor with reversed levels
LC_depth$depth <- factor(factor(LC_depth$depth), levels=rev(levels(factor(LC_depth$depth))))

#convert site to an factor with ordered levels
LC_depth$site <- factor(factor(LC_depth$site), levels(factor(LC_depth$site))[c(1,3,6,4,10,5,9,11,8,7,2)])


# filter for zebra and quagga mussels
LC_depth.z <- LC_depth[LC_depth$species=="zebra",] 
LC_depth.q <- LC_depth[LC_depth$species=="quagga",] 



#################Figure 6: Density across depth##############
# Plot for depth profile of quagga mussel abundance of Lake Constance depth monitoring 2019



# create 3 data points for the plot for better visualization
# we did sample but did not find quagga mussels
# in the violin plots, its shown as a thin line
# therefore we included a point with the same data as in the data LC_depth
ber<- data.frame(site=factor("Berlingen"), density=0, depth="45", species="quagga", lake="Untersee")
rad <- data.frame(site=factor("Radolfzell"), density= 0, depth="20", species="quagga", lake="Untersee")
rei <- data.frame(site=factor("Reichenau"), density=0, depth="20", species="quagga", lake="Untersee")


plot6<- ggplot(LC_depth.q, aes(x=depth,y=(density+1), fill=depth))+
  geom_violin(width=1.5)+
  scale_fill_viridis(discrete=T, name="Depth") + coord_flip()+
  scale_y_log10(breaks = c(1 ,10, 100,1000, 10000),
                labels= c(0, expression(paste("10"^"1")),
                          expression(paste("10"^"2")), 
                          expression(paste("10"^"3")),
                          expression(paste("10"^"4"))) )+
  theme( legend.position="none")+
  

  
  labs(y=expression("Density (individuals / m"^"2"*")"),
       x=" Depth (m)")+
  #following points are only for visualization. 
  #the violin of 0 shows only a line in the plot, almost not visible. 
  #the point only represents-> was sampled, but density found is 0
    geom_point(data=ber, col="#21908CFF",size=2, show.legend=FALSE)+
    geom_point(data = rad, col="#8FD744FF",size=2, show.legend=FALSE)+
   geom_point(data= rei, col="#8FD744FF",size=2, show.legend=FALSE)+
  facet_wrap(.~site)


plot6


###########Statistics: Lake Constance Dreissenid counts across depths#########
#Mussel counts were analysed using zero inflated generalized linear models 
#and a negative binomial distribution with depth as explanatory variable and site as random effect.

#exclude Untersee and Wallhausen from the analysis
LC_depth.q <- LC_depth.q[LC_depth.q$lake!="Untersee",] 
LC_depth.q <- LC_depth.q[LC_depth.q$site!= "Wallhausen",] 


#fit the model
model_depth <- glmmTMB(dreissena_nr ~ depth+ (1|site), family=nbinom2, data=LC_depth.q, ziformula=~1)

#get summary statistics
summary(model_depth) 
glmmTMB:::Anova.glmmTMB(model_depth) 

#null model comparisons
model0 <- glmmTMB(dreissena_nr ~ 1 + (1|site), family=nbinom2, data=LC_depth.q, ziformula=~1)
anova(model0, model_depth, test = "Chisq")#model with site, is sig better than only with depth


#qqplot
qqPlot(resid(model_depth), dist = "norm",
       mean = mean(resid(model_depth)), sd = sd(resid(model_depth)),
       xlab = "theoretic quantiles", ylab = "empiric quantiles",
       main = "Q-Q-Plot of residuals")


## check model  assumptions with package DHARMa

#first calculate the residuals of the model
#tests for   correct distribution (KS test), dispersion and outliers-all non sig
simulationOutput <- simulateResiduals(fittedModel  = model_depth, plot = T)
testZeroInflation(simulationOutput) # formal rest for zero-inflation, non sign 




##################Figure S3: coefficient of variation###############
# the coefficient of variation is based on mussel counts in our samples. 

#load the data and edit the structure
cv <- read.table("./data/lakeconstance_depth_dreissena_sampling_2019_cv.txt", header=T)
cv$depth <- as.factor(cv$depth)
cv$depth <- factor(cv$depth, levels=rev(levels(cv$depth)))


##Figure 6l: CV and depth
cvplot<-ggplot(data=cv, aes(x=depth, y=cv))+
  geom_point()+
  geom_boxplot()+coord_flip()+
  labs(x=" Depth (m)", y= "Coefficent of variation")
cvplot



#Figure S3: CV and mussel abundance
ggplot(data=cv, aes(x=cv, y=mean))+
  geom_point()+
  geom_smooth(method="lm",fill="grey87")+
  labs(x="Coefficent of variation", 
       y=expression(Mussel~count~(individuals~"/"~37~cm^2)))

#################Statistics: CV and depth or mussel abundance###############

##Analysis of CV and depth

#analysis of normality
shapiro.test(cv$cv) #non sig - the test can state that there exists no significant departure from normality
hist(cv$cv)

#fit model and get summary statistics
model_cv_depth <- lme(cv ~ depth ,random= ~1|site,data=cv, method="ML") #sames as mc022

summary(model_cv_depth) #this model used! 

#Post-Hoc tests

#set contrasts
c1_30vs60 <- c(0,1,0) #comparing 30m vs 60m
c1_30vs80 <- c(0,0,1) #comparing 30m vs 80m
contrasts(cv$depth) <- cbind(c1_30vs60, c1_30vs80)

# Post Hoc test: differences of CV between depth
post.d<- glht(model_cv_depth, linfct=mcp(depth="Tukey")) 
summary(post.d) ## only sign difference of CV between 30 am 60m
confint(post.d)

##Analysis: CV and abundance
#We analysed if CV has an effect on mussel counts in a generalized linear model 
#with a negative binomial distribution to account for overdispersion with site as random factor.

#round the mean nr. of mussels per site and depth to whole numbers
cv$mean.round <- round(cv$mean) #round the mean=nr.total to 0 digits

#fit the model and get summary statistics
model_cv_abd <- glmmTMB(mean.round ~ cv + (1|site), data=cv, family = nbinom2) #stay with this
summary(model_cv_abd)
glmmTMB:::Anova.glmmTMB(model_cv_abd) 

#Model assumptions
testDispersion(model_cv_abd)
#tests for   correct distribution (KS test), dispersion and outliers. 
simulationOutput <- simulateResiduals(fittedModel = model_cv_abd, plot = T)
